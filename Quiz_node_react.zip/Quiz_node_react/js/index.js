 var React = require("react");
var ReactDOM = require("react-dom");

 var Button = ReactBootstrap.Button;
 
	var HomeCmp = React.createClass({
             getInitialState :function(){
                    return {
                      category : false
                    }
                },
                showCategory : function(){
                     this.setState({category : true});
                },
                render : function(){
                          return <div>
                          {this.state.category ?  <CategoryCmp/> : <Button onClick={this.showCategory}><Link to="/category">Start Quiz !!</Link></Button>}
                          </div>
                }
       });
	   
       var CategoryCmp = React.createClass({
              render : function(){
                    return (
                      <div><h1>Quiz category </h1> </div>
                      )
              }
       });
	   
       var {Router,
            Route,
            IndexRedirect,
            hashHistory,
            Link } = ReactRouter;
			
            ReactDOM.render(
                  <Router history={ReactRouter.hashHistory}>
                          <Route path="/" component={HomeCmp}>
                                 	<IndexRedirect to="/home" />
                                    	<Route path="/home" component={HomeCmp} />
                                        <Route path="/category" component={CategoryCmp} />
                          </Route>
                  </Router>,
                  document.getElementById('container')
            );