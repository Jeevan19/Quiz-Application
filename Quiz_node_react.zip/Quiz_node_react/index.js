
var express = require('express');
//var fs = require('fs');
//var http = require('http');
var bodyParser = require('body-parser');
//var path    = require("path");
var application_root = __dirname,
  app = express();
/*
  fs.readFile('./index.html', function (err, html) {
      if (err) {
          throw err;
      }
  http.createServer(function(request, response) {
         response.writeHeader(200, {"Content-Type": "text/html"});
         response.write(html);
         response.end();
  }).listen(80);
});

*/
//Note that in version 4 of express, express.bodyParser() was
//deprecated in favor of a separate 'body-parser' module.
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(application_root));

app.get('/',function(req,res){
  res.sendFile(__dirname+'/index.html');
});

app.get('/catData',function(req,res){
  fs = require('fs')
 fs.readFile('../Quiz_node_react/data.json', 'utf8', function (err,data) {
 if (err) {
 return console.log(err);
 }
 console.log(data);
 res.send(data); 
 });
});

app.get('/questionSet/:value',function(req,res){
//  fs = require('fs')
 fs.readFile('../Quiz_node_react/questions.json', 'utf8', function (err,data) {
 if (err) {
 return console.log(err);
 }
 console.log(req.params.value);
 var input= JSON.parse(data);
 console.log(input)
 var  val=(req.params.value);
 
  
 res.send(input[val]); 
 });
});
/*
app.get('/',function(req,res){
  res.redirect('/login');
});

app.get('/login',function(req,res){
  res.redirect((path.join(__dirname + '/views/login'));
});
*/

app.get('/', function (req, res){
	//res.render('quiz test',{});
  res.sendFile('React_express.html');
});
app.post('/myaction', function(req, res) {
  res.send('You sent the name "' + req.body.q1 + '"."' + req.body.q2 + '"."' + req.body.q3 + '"."' + req.body.q4 + '".');
});

app.listen(8000, function() {
  console.log('Server running at http://127.0.0.1:8000/');
});



/*
// Read Synchrously
 var fs = require("fs");
 console.log("\n *START* \n");

 fs.readFile('./dummy.json', 'utf8', function (err, data) {
    if (err) throw err; // we'll not consider error handling for now
    var obj = JSON.parse(data);
    console.dir(obj);
 });
 //var content = fs.readFileSync("dummy.json");
 //var jsonContent = JSON.parse(content);
 //console.log("Output Content : \n"+ content);
 //console.log("User Name:", jsonContent.username);
 //console.log("Email:", jsonContent.email);
 //console.log("Password:", jsonContent.password);
 console.log("\n *EXIT* \n");
*/
